class SchedulerModel {
  final String task;
  final String notifyAt;
  final String isActive;

  SchedulerModel(
      {required this.task, required this.notifyAt, required this.isActive});
}
