
bool isEnglish = false;

class PageConst{
  static const String home = "home";
}