const String learnAbout = 'Learn_About';

class Fontsize {
   double h2 = 22.0;
   double h3 = 16.0;
   double h4 = 14.0;
   double h5 = 12.0;
   double h6 = 8.0;
   
}

